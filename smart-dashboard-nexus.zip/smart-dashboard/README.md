# Nexus — Smart Personal Dashboard

A production-grade personal dashboard built with React, TypeScript, and Tailwind CSS.

## Features

- **Authentication** — Register/login with localStorage persistence
- **Dashboard Widgets**
  - 🕐 Live Clock
  - 🌤️ Weather (Open-Meteo API — no key required, auto-detects your location)
  - 💬 Quote of the Day
  - ✅ To-Do List with priorities, filtering, CRUD
  - 📝 Notes with color coding
- **Drag & Drop** — Reorder widgets freely
- **Dark/Light mode** toggle
- **Settings panel** — Show/hide any widget
- Fully responsive (mobile + desktop)

## Setup

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Build

```bash
npm run build
npm run preview
```

## Stack

- Vite + React 19 + TypeScript
- Tailwind CSS 3
- @hello-pangea/dnd (drag and drop)
- lucide-react (icons)
- Open-Meteo (weather API — free, no key)
- ipapi.co (geolocation — free)

## Folder Structure

```
src/
├── components/
│   ├── layout/       # Sidebar, Topbar
│   ├── ui/           # WidgetCard, Spinner
│   └── widgets/      # ClockWidget, WeatherWidget, etc.
├── context/          # AuthContext, ThemeContext, SettingsContext
├── hooks/            # useWeather, useTodos, useNotes, useQuote, useClock
├── pages/            # AuthPage, DashboardPage, SettingsPage
└── types/            # Shared TypeScript types
```
