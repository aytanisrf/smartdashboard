import { useState } from 'react';
import { useAuth } from './context/AuthContext';
import { AuthPage } from './pages/AuthPage';
import { DashboardPage } from './pages/DashboardPage';
import { SettingsPage } from './pages/SettingsPage';
import { Sidebar } from './components/layout/Sidebar';
import { Topbar } from './components/layout/Topbar';
import { SettingsProvider } from './context/SettingsContext';

type Page = 'dashboard' | 'settings';

function AppShell() {
  const [page, setPage] = useState<Page>('dashboard');
  const titles: Record<Page, string> = { dashboard: 'Dashboard', settings: 'Settings' };

  return (
    <SettingsProvider>
      <div className="h-screen flex bg-surface-50 dark:bg-surface-950 overflow-hidden">
        <Sidebar currentPage={page} onNavigate={setPage} />
        <div className="flex-1 flex flex-col min-w-0">
          <Topbar title={titles[page]} />
          <main className="flex-1 overflow-y-auto">
            {page === 'dashboard' && <DashboardPage />}
            {page === 'settings' && <SettingsPage />}
          </main>
        </div>
      </div>
    </SettingsProvider>
  );
}

export default function App() {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <AppShell /> : <AuthPage />;
}
