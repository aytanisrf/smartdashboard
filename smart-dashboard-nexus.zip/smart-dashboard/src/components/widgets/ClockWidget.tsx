import { Clock } from 'lucide-react';
import { useClock } from '../../hooks/useClock';
import { WidgetCard } from '../ui/WidgetCard';

export function ClockWidget() {
  const { hours, minutes, seconds, date } = useClock();

  return (
    <WidgetCard title="Clock" icon={<Clock className="w-4 h-4" />}>
      <div className="flex flex-col items-center py-2">
        <div className="font-mono text-5xl font-medium tracking-tight text-zinc-800 dark:text-zinc-100 tabular-nums">
          <span>{hours}</span>
          <span className="animate-pulse mx-1 text-accent-500">:</span>
          <span>{minutes}</span>
          <span className="text-3xl text-zinc-400 dark:text-zinc-500">:{seconds}</span>
        </div>
        <p className="mt-3 text-sm text-zinc-500 dark:text-zinc-400">{date}</p>
      </div>
    </WidgetCard>
  );
}
