import { useState } from 'react';
import { StickyNote, Plus, X } from 'lucide-react';
import { useNotes } from '../../hooks/useNotes';
import { WidgetCard } from '../ui/WidgetCard';
import { useAuth } from '../../context/AuthContext';
import type { Note } from '../../types';

function NoteCard({ note, onUpdate, onDelete }: {
  note: Note;
  onUpdate: (id: string, fields: Partial<Pick<Note, 'title' | 'content' | 'color'>>) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div
      className="rounded-xl p-3 relative group"
      style={{ backgroundColor: note.color + '22', borderLeft: `3px solid ${note.color}` }}
    >
      <button
        onClick={() => onDelete(note.id)}
        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-red-400 transition-all"
      >
        <X className="w-3.5 h-3.5" />
      </button>
      <input
        value={note.title}
        onChange={e => onUpdate(note.id, { title: e.target.value })}
        placeholder="Title..."
        className="w-full bg-transparent text-sm font-semibold text-zinc-700 dark:text-zinc-200 outline-none placeholder-zinc-400 mb-1.5 pr-5"
      />
      <textarea
        value={note.content}
        onChange={e => onUpdate(note.id, { content: e.target.value })}
        placeholder="Write something..."
        rows={3}
        className="w-full bg-transparent text-xs text-zinc-600 dark:text-zinc-400 outline-none resize-none placeholder-zinc-400 leading-relaxed"
      />
      <div className="flex gap-1 mt-2">
        {['#fbbf24', '#34d399', '#60a5fa', '#f87171', '#a78bfa', '#fb923c'].map(c => (
          <button
            key={c}
            onClick={() => onUpdate(note.id, { color: c })}
            className="w-3.5 h-3.5 rounded-full transition-transform hover:scale-125"
            style={{ backgroundColor: c, outline: note.color === c ? `2px solid ${c}` : 'none', outlineOffset: '1px' }}
          />
        ))}
      </div>
    </div>
  );
}

export function NotesWidget() {
  const { user } = useAuth();
  const { notes, add, update, remove } = useNotes(user!.id);
  const [expanded, setExpanded] = useState(false);

  const visible = expanded ? notes : notes.slice(0, 2);

  return (
    <WidgetCard
      title="Notes"
      icon={<StickyNote className="w-4 h-4" />}
      action={
        <button onClick={add} className="btn-ghost p-1.5 text-zinc-400 hover:text-accent-500">
          <Plus className="w-4 h-4" />
        </button>
      }
    >
      <div className="space-y-2.5">
        {notes.length === 0 && (
          <div className="text-center py-6">
            <StickyNote className="w-8 h-8 text-zinc-300 dark:text-zinc-600 mx-auto mb-2" />
            <p className="text-sm text-zinc-400">No notes yet. Click + to add one.</p>
          </div>
        )}
        <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
          {visible.map(note => (
            <NoteCard key={note.id} note={note} onUpdate={update} onDelete={remove} />
          ))}
        </div>
        {notes.length > 2 && (
          <button
            onClick={() => setExpanded(e => !e)}
            className="w-full text-xs text-accent-500 hover:text-accent-600 transition-colors py-1"
          >
            {expanded ? 'Show less' : `Show ${notes.length - 2} more`}
          </button>
        )}
      </div>
    </WidgetCard>
  );
}
