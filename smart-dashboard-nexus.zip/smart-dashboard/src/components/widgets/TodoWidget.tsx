import { useState, type KeyboardEvent } from 'react';
import { CheckSquare, Plus, Trash2, Circle, CheckCircle2 } from 'lucide-react';
import { useTodos } from '../../hooks/useTodos';
import { WidgetCard } from '../ui/WidgetCard';
import { useAuth } from '../../context/AuthContext';
import type { Todo } from '../../types';

const PRIORITY_COLORS: Record<Todo['priority'], string> = {
  low: 'bg-emerald-400',
  medium: 'bg-amber-400',
  high: 'bg-red-400',
};

export function TodoWidget() {
  const { user } = useAuth();
  const { todos, add, toggle, remove, clearCompleted } = useTodos(user!.id);
  const [input, setInput] = useState('');
  const [priority, setPriority] = useState<Todo['priority']>('medium');
  const [filter, setFilter] = useState<'all' | 'active' | 'done'>('all');

  const handleAdd = () => {
    if (!input.trim()) return;
    add(input.trim(), priority);
    setInput('');
  };

  const handleKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleAdd();
  };

  const filtered = todos.filter(t => {
    if (filter === 'active') return !t.completed;
    if (filter === 'done') return t.completed;
    return true;
  });

  const doneCount = todos.filter(t => t.completed).length;

  return (
    <WidgetCard
      title="To-Do List"
      icon={<CheckSquare className="w-4 h-4" />}
      action={
        doneCount > 0 ? (
          <button onClick={clearCompleted} className="text-xs text-zinc-400 hover:text-red-400 transition-colors">
            Clear done ({doneCount})
          </button>
        ) : undefined
      }
    >
      <div className="space-y-3">
        {/* Input */}
        <div className="flex gap-2">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Add a task..."
            className="input-base flex-1 text-sm py-2"
          />
          <select
            value={priority}
            onChange={e => setPriority(e.target.value as Todo['priority'])}
            className="input-base w-auto px-2 text-xs"
          >
            <option value="low">Low</option>
            <option value="medium">Med</option>
            <option value="high">High</option>
          </select>
          <button onClick={handleAdd} className="btn-primary px-3 py-2">
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-1 text-xs">
          {(['all', 'active', 'done'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-lg capitalize transition-all ${
                filter === f
                  ? 'bg-accent-500/15 text-accent-500 font-medium'
                  : 'text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* List */}
        <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
          {filtered.length === 0 && (
            <p className="text-center text-sm text-zinc-400 py-4">Nothing here yet</p>
          )}
          {filtered.map(todo => (
            <div
              key={todo.id}
              className="flex items-center gap-2.5 group p-2 rounded-xl hover:bg-surface-100 dark:hover:bg-surface-800/60 transition-colors"
            >
              <button onClick={() => toggle(todo.id)} className="shrink-0 text-zinc-300 dark:text-zinc-600 hover:text-accent-500 transition-colors">
                {todo.completed
                  ? <CheckCircle2 className="w-4 h-4 text-accent-500" />
                  : <Circle className="w-4 h-4" />
                }
              </button>
              <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${PRIORITY_COLORS[todo.priority]}`} />
              <span className={`flex-1 text-sm ${todo.completed ? 'line-through text-zinc-400' : 'text-zinc-700 dark:text-zinc-200'}`}>
                {todo.text}
              </span>
              <button
                onClick={() => remove(todo.id)}
                className="opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-red-400 transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {todos.length > 0 && (
          <p className="text-xs text-zinc-400 text-right">
            {doneCount}/{todos.length} completed
          </p>
        )}
      </div>
    </WidgetCard>
  );
}
