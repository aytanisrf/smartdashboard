import { Cloud, Droplets, Wind, Thermometer } from 'lucide-react';
import { useWeather } from '../../hooks/useWeather';
import { WidgetCard } from '../ui/WidgetCard';
import { Spinner } from '../ui/Spinner';

export function WeatherWidget() {
  const { data, loading, error } = useWeather();

  return (
    <WidgetCard title="Weather" icon={<Cloud className="w-4 h-4" />}>
      {loading && (
        <div className="flex justify-center py-6">
          <Spinner />
        </div>
      )}
      {error && (
        <div className="text-sm text-red-400 text-center py-4">{error}</div>
      )}
      {data && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-4xl font-light text-zinc-800 dark:text-zinc-100">
                {data.temp}°C
              </div>
              <div className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">{data.condition}</div>
              <div className="text-xs text-zinc-400 dark:text-zinc-500 mt-0.5">{data.city}</div>
            </div>
            <div className="text-5xl">{data.icon}</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[
              { icon: <Thermometer className="w-3.5 h-3.5" />, label: 'Feels like', value: `${data.feelsLike}°` },
              { icon: <Droplets className="w-3.5 h-3.5" />, label: 'Humidity', value: `${data.humidity}%` },
              { icon: <Wind className="w-3.5 h-3.5" />, label: 'Wind', value: `${data.windSpeed} km/h` },
            ].map(({ icon, label, value }) => (
              <div key={label} className="bg-surface-100 dark:bg-surface-800/60 rounded-xl p-2.5 text-center">
                <div className="flex justify-center text-accent-500 mb-1">{icon}</div>
                <div className="text-xs text-zinc-400 dark:text-zinc-500">{label}</div>
                <div className="text-sm font-medium text-zinc-700 dark:text-zinc-300 mt-0.5">{value}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </WidgetCard>
  );
}
