import { Quote, RefreshCw } from 'lucide-react';
import { useQuote } from '../../hooks/useQuote';
import { WidgetCard } from '../ui/WidgetCard';
import { Spinner } from '../ui/Spinner';

export function QuoteWidget() {
  const { quote, loading, refresh } = useQuote();

  return (
    <WidgetCard
      title="Quote of the Day"
      icon={<Quote className="w-4 h-4" />}
      action={
        <button
          onClick={refresh}
          className="btn-ghost p-1.5 text-zinc-400 hover:text-accent-500"
          title="New quote"
        >
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      }
    >
      {loading ? (
        <div className="flex justify-center py-4"><Spinner /></div>
      ) : quote ? (
        <div className="space-y-3">
          <div className="relative">
            <span className="absolute -top-2 -left-1 text-4xl text-accent-500/20 font-display leading-none select-none">"</span>
            <p className="text-sm leading-relaxed text-zinc-600 dark:text-zinc-300 pl-4 italic">
              {quote.text}
            </p>
          </div>
          <p className="text-xs font-medium text-accent-500 pl-4">— {quote.author}</p>
        </div>
      ) : null}
    </WidgetCard>
  );
}
