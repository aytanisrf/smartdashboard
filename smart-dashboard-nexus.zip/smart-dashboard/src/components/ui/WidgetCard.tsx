import { type ReactNode } from 'react';

interface WidgetCardProps {
  title: string;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
  action?: ReactNode;
}

export function WidgetCard({ title, icon, children, className = '', action }: WidgetCardProps) {
  return (
    <div className={`glass-card p-5 flex flex-col gap-4 animate-slide-up ${className}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {icon && (
            <div className="w-7 h-7 rounded-lg bg-accent-500/10 flex items-center justify-center text-accent-500">
              {icon}
            </div>
          )}
          <span className="font-display text-sm font-semibold text-zinc-700 dark:text-zinc-300 tracking-wide uppercase">
            {title}
          </span>
        </div>
        {action && <div>{action}</div>}
      </div>
      <div className="flex-1">{children}</div>
    </div>
  );
}
