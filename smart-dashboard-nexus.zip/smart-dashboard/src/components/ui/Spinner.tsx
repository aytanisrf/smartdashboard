interface SpinnerProps { size?: 'sm' | 'md' | 'lg'; }

export function Spinner({ size = 'md' }: SpinnerProps) {
  const s = { sm: 'w-4 h-4', md: 'w-6 h-6', lg: 'w-8 h-8' }[size];
  return (
    <div className={`${s} border-2 border-accent-500/30 border-t-accent-500 rounded-full animate-spin`} />
  );
}
