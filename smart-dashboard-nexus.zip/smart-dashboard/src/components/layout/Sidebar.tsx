import { useState } from 'react';
import { LayoutDashboard, Settings, LogOut, Zap, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  currentPage: 'dashboard' | 'settings';
  onNavigate: (page: 'dashboard' | 'settings') => void;
}

export function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  const { logout } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  const navItems = [
    { id: 'dashboard' as const, icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'settings' as const, icon: Settings, label: 'Settings' },
  ];

  return (
    <aside className={`hidden md:flex flex-col h-full glass border-r border-surface-200/60 dark:border-white/5 transition-all duration-300 ${collapsed ? 'w-16' : 'w-56'}`}>
      {/* Logo */}
      <div className={`flex items-center gap-3 p-4 border-b border-surface-200/40 dark:border-white/5 ${collapsed ? 'justify-center' : ''}`}>
        <div className="w-8 h-8 bg-gradient-to-br from-accent-500 to-purple-400 rounded-lg flex items-center justify-center shrink-0 shadow-glow-sm">
          <Zap className="w-4 h-4 text-white" />
        </div>
        {!collapsed && (
          <span className="font-display text-base font-bold text-zinc-800 dark:text-zinc-100">
            Nexus
          </span>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 p-2 space-y-1 mt-2">
        {navItems.map(({ id, icon: Icon, label }) => (
          <button
            key={id}
            onClick={() => onNavigate(id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group
              ${currentPage === id
                ? 'bg-accent-500/10 text-accent-500'
                : 'text-zinc-500 dark:text-zinc-400 hover:bg-surface-100 dark:hover:bg-surface-800 hover:text-zinc-700 dark:hover:text-zinc-200'
              } ${collapsed ? 'justify-center' : ''}`}
          >
            <Icon className="w-4 h-4 shrink-0" />
            {!collapsed && <span className="text-sm font-medium">{label}</span>}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-2 border-t border-surface-200/40 dark:border-white/5 space-y-1">
        <button
          onClick={() => setCollapsed(c => !c)}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-zinc-400 hover:bg-surface-100 dark:hover:bg-surface-800 transition-colors ${collapsed ? 'justify-center' : ''}`}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <><ChevronLeft className="w-4 h-4" /><span className="text-xs">Collapse</span></>}
        </button>
        <button
          onClick={logout}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-zinc-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-500 transition-colors ${collapsed ? 'justify-center' : ''}`}
        >
          <LogOut className="w-4 h-4 shrink-0" />
          {!collapsed && <span className="text-sm">Log out</span>}
        </button>
      </div>
    </aside>
  );
}
