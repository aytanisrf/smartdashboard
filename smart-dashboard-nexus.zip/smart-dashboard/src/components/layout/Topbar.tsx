import { Sun, Moon, Bell, Menu } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';

interface TopbarProps {
  title: string;
  onMenuToggle?: () => void;
}

export function Topbar({ title, onMenuToggle }: TopbarProps) {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();

  const initials = user?.name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2) ?? '?';

  return (
    <header className="glass border-b border-surface-200/60 dark:border-white/5 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button onClick={onMenuToggle} className="md:hidden btn-ghost p-2">
          <Menu className="w-5 h-5" />
        </button>
        <h1 className="font-display text-lg font-bold text-zinc-800 dark:text-zinc-100">{title}</h1>
      </div>

      <div className="flex items-center gap-1.5">
        <button
          onClick={toggleTheme}
          className="btn-ghost p-2 relative overflow-hidden"
          title="Toggle theme"
        >
          {theme === 'dark'
            ? <Sun className="w-4 h-4 text-amber-400" />
            : <Moon className="w-4 h-4 text-indigo-500" />
          }
        </button>

        <button className="btn-ghost p-2 relative">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-accent-500 rounded-full" />
        </button>

        <div className="flex items-center gap-2.5 ml-2 pl-2 border-l border-surface-200/60 dark:border-white/10">
          <div className="w-8 h-8 bg-gradient-to-br from-accent-500 to-purple-400 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-glow-sm">
            {initials}
          </div>
          <div className="hidden sm:block">
            <p className="text-sm font-medium text-zinc-700 dark:text-zinc-200 leading-none">{user?.name}</p>
            <p className="text-xs text-zinc-400 mt-0.5 leading-none">{user?.email}</p>
          </div>
        </div>
      </div>
    </header>
  );
}
