import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import type { DropResult } from '@hello-pangea/dnd';
import { GripVertical } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { ClockWidget } from '../components/widgets/ClockWidget';
import { WeatherWidget } from '../components/widgets/WeatherWidget';
import { QuoteWidget } from '../components/widgets/QuoteWidget';
import { TodoWidget } from '../components/widgets/TodoWidget';
import { NotesWidget } from '../components/widgets/NotesWidget';
import type { WidgetConfig } from '../types';
import type { ReactNode } from 'react';

const WIDGET_MAP: Record<string, ReactNode> = {
  clock: <ClockWidget />,
  weather: <WeatherWidget />,
  quote: <QuoteWidget />,
  todo: <TodoWidget />,
  notes: <NotesWidget />,
};

export function DashboardPage() {
  const { widgets, reorderWidgets } = useSettings();

  const visibleWidgets = [...widgets]
    .filter(w => w.visible)
    .sort((a, b) => a.order - b.order);

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    const items = [...visibleWidgets];
    const [moved] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, moved);
    const hidden = widgets.filter(w => !w.visible);
    reorderWidgets([...items, ...hidden]);
  };

  return (
    <div className="p-4 md:p-6 animate-fade-in">
      <div className="mb-6">
        <h2 className="font-display text-2xl font-bold text-zinc-800 dark:text-zinc-100">
          Your Dashboard
        </h2>
        <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
          Drag widgets to rearrange · Toggle visibility in Settings
        </p>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="dashboard">
          {(provided) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4"
            >
              {visibleWidgets.map((widget: WidgetConfig, index: number) => (
                <Draggable key={widget.id} draggableId={widget.id} index={index}>
                  {(drag, snapshot) => (
                    <div
                      ref={drag.innerRef}
                      {...drag.draggableProps}
                      className={`relative group transition-all duration-200 ${
                        snapshot.isDragging ? 'scale-[1.02] shadow-glow z-50' : ''
                      }`}
                    >
                      <div
                        {...drag.dragHandleProps}
                        className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity cursor-grab active:cursor-grabbing text-zinc-400 hover:text-accent-500"
                      >
                        <GripVertical className="w-4 h-4" />
                      </div>
                      {WIDGET_MAP[widget.id]}
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      {visibleWidgets.length === 0 && (
        <div className="text-center py-24 text-zinc-400">
          <p className="text-lg">No widgets visible</p>
          <p className="text-sm mt-1">Go to Settings to enable some widgets</p>
        </div>
      )}
    </div>
  );
}
