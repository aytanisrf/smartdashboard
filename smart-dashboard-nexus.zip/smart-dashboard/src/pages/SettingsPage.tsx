import { Settings, Eye, EyeOff } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import type { WidgetId } from '../types';

export function SettingsPage() {
  const { widgets, toggleWidget } = useSettings();

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h2 className="font-display text-2xl font-bold text-zinc-800 dark:text-zinc-100">Settings</h2>
        <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">Customize your dashboard experience</p>
      </div>

      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Settings className="w-4 h-4 text-accent-500" />
          <h3 className="font-semibold text-zinc-700 dark:text-zinc-200">Widget Visibility</h3>
        </div>

        <div className="space-y-2">
          {widgets.map(widget => (
            <div
              key={widget.id}
              className="flex items-center justify-between p-3 rounded-xl hover:bg-surface-100 dark:hover:bg-surface-800/60 transition-colors"
            >
              <div>
                <p className="text-sm font-medium text-zinc-700 dark:text-zinc-200">{widget.title}</p>
                <p className="text-xs text-zinc-400 mt-0.5">
                  {widget.visible ? 'Visible on dashboard' : 'Hidden'}
                </p>
              </div>
              <button
                onClick={() => toggleWidget(widget.id as WidgetId)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  widget.visible
                    ? 'bg-accent-500/10 text-accent-500 hover:bg-accent-500/20'
                    : 'bg-surface-100 dark:bg-surface-800 text-zinc-400 hover:text-zinc-600'
                }`}
              >
                {widget.visible
                  ? <><Eye className="w-3.5 h-3.5" /> Visible</>
                  : <><EyeOff className="w-3.5 h-3.5" /> Hidden</>
                }
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="glass-card p-6 space-y-4">
        <h3 className="font-semibold text-zinc-700 dark:text-zinc-200">About</h3>
        <div className="space-y-2 text-sm text-zinc-500 dark:text-zinc-400">
          <p>Nexus Dashboard v1.0.0</p>
          <p>Your personal productivity hub — built with React, TypeScript & Tailwind CSS.</p>
        </div>
      </div>
    </div>
  );
}
