import { useState, useEffect } from 'react';
import type { WeatherData } from '../types';

// Using Open-Meteo (free, no key required) + ip-api for location
export function useWeather() {
  const [data, setData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    const weatherCodes: Record<number, string> = {
      0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
      45: 'Foggy', 48: 'Icy fog', 51: 'Light drizzle', 53: 'Drizzle',
      55: 'Heavy drizzle', 61: 'Light rain', 63: 'Rain', 65: 'Heavy rain',
      71: 'Light snow', 73: 'Snow', 75: 'Heavy snow', 80: 'Rain showers',
      81: 'Showers', 82: 'Heavy showers', 95: 'Thunderstorm',
    };

    const getIcon = (code: number, isDay: boolean) => {
      if (code === 0 || code === 1) return isDay ? '☀️' : '🌙';
      if (code <= 3) return '⛅';
      if (code <= 48) return '🌫️';
      if (code <= 67) return '🌧️';
      if (code <= 77) return '❄️';
      if (code <= 82) return '🌦️';
      return '⛈️';
    };

    async function fetchWeather() {
      try {
        // Get user location by IP
        const geoRes = await fetch('https://ipapi.co/json/');
        const geo = await geoRes.json();
        const { latitude, longitude, city } = geo;

        // Open-Meteo: free weather API
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,apparent_temperature,weathercode,windspeed_10m,relativehumidity_2m,is_day&wind_speed_unit=kmh`;
        const weatherRes = await fetch(url);
        const weather = await weatherRes.json();
        const c = weather.current;

        if (cancelled) return;
        setData({
          city: city || 'Your Location',
          temp: Math.round(c.temperature_2m),
          feelsLike: Math.round(c.apparent_temperature),
          condition: weatherCodes[c.weathercode] ?? 'Unknown',
          humidity: c.relativehumidity_2m,
          windSpeed: Math.round(c.windspeed_10m),
          icon: getIcon(c.weathercode, c.is_day === 1),
        });
      } catch {
        if (!cancelled) setError('Unable to load weather');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchWeather();
    return () => { cancelled = true; };
  }, []);

  return { data, loading, error };
}
