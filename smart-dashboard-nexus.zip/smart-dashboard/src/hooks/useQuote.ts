import { useState, useEffect } from 'react';
import type { Quote } from '../types';

const FALLBACK_QUOTES: Quote[] = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "Innovation distinguishes between a leader and a follower.", author: "Steve Jobs" },
  { text: "Stay hungry, stay foolish.", author: "Steve Jobs" },
  { text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
  { text: "Life is what happens when you're busy making other plans.", author: "John Lennon" },
  { text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney" },
  { text: "Success is not final, failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
  { text: "You miss 100% of the shots you don't take.", author: "Wayne Gretzky" },
];

const CACHE_KEY = 'nexus_quote_cache';

export function useQuote() {
  const [quote, setQuote] = useState<Quote | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const today = new Date().toDateString();
    const cached = localStorage.getItem(CACHE_KEY);

    if (cached) {
      try {
        const { date, data } = JSON.parse(cached);
        if (date === today) {
          setQuote(data);
          setLoading(false);
          return;
        }
      } catch { /* ignore */ }
    }

    // Use deterministic daily fallback (no API key required)
    const dayIndex = new Date().getDate() % FALLBACK_QUOTES.length;
    const selected = FALLBACK_QUOTES[dayIndex];
    setQuote(selected);
    localStorage.setItem(CACHE_KEY, JSON.stringify({ date: today, data: selected }));
    setLoading(false);
  }, []);

  const refresh = () => {
    localStorage.removeItem(CACHE_KEY);
    const random = FALLBACK_QUOTES[Math.floor(Math.random() * FALLBACK_QUOTES.length)];
    setQuote(random);
  };

  return { quote, loading, refresh };
}
