import { useState, useEffect, useCallback } from 'react';
import type { Note } from '../types';

const STORAGE_KEY = 'nexus_notes';
const NOTE_COLORS = ['#fbbf24', '#34d399', '#60a5fa', '#f87171', '#a78bfa', '#fb923c'];

export function useNotes(userId: string) {
  const key = `${STORAGE_KEY}_${userId}`;

  const [notes, setNotes] = useState<Note[]>(() => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : [];
    } catch { return []; }
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(notes));
  }, [notes, key]);

  const add = useCallback(() => {
    const note: Note = {
      id: crypto.randomUUID(),
      title: '',
      content: '',
      color: NOTE_COLORS[Math.floor(Math.random() * NOTE_COLORS.length)],
      updatedAt: new Date().toISOString(),
    };
    setNotes(prev => [note, ...prev]);
    return note.id;
  }, []);

  const update = useCallback((id: string, fields: Partial<Pick<Note, 'title' | 'content' | 'color'>>) => {
    setNotes(prev =>
      prev.map(n => n.id === id ? { ...n, ...fields, updatedAt: new Date().toISOString() } : n)
    );
  }, []);

  const remove = useCallback((id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
  }, []);

  return { notes, add, update, remove, NOTE_COLORS };
}
