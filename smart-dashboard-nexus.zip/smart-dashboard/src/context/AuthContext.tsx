import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { User, AuthState } from '../types';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const STORAGE_KEY = 'nexus_auth';
const USERS_KEY = 'nexus_users';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try { return JSON.parse(stored); } catch { /* ignore */ }
    }
    return { user: null, isAuthenticated: false };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const getUsers = (): Record<string, { password: string; user: User }> => {
    const stored = localStorage.getItem(USERS_KEY);
    try { return stored ? JSON.parse(stored) : {}; } catch { return {}; }
  };

  const login = async (email: string, password: string) => {
    await new Promise(r => setTimeout(r, 600)); // simulate network
    const users = getUsers();
    const entry = users[email.toLowerCase()];
    if (!entry || entry.password !== password) {
      return { success: false, error: 'Invalid email or password' };
    }
    setState({ user: entry.user, isAuthenticated: true });
    return { success: true };
  };

  const register = async (name: string, email: string, password: string) => {
    await new Promise(r => setTimeout(r, 600));
    const users = getUsers();
    if (users[email.toLowerCase()]) {
      return { success: false, error: 'Email already in use' };
    }
    const user: User = {
      id: crypto.randomUUID(),
      name,
      email: email.toLowerCase(),
      createdAt: new Date().toISOString(),
    };
    users[email.toLowerCase()] = { password, user };
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    setState({ user, isAuthenticated: true });
    return { success: true };
  };

  const logout = () => {
    setState({ user: null, isAuthenticated: false });
  };

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
