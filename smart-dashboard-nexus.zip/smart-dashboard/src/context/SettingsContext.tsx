import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { WidgetConfig, WidgetId } from '../types';

interface SettingsContextType {
  widgets: WidgetConfig[];
  toggleWidget: (id: WidgetId) => void;
  reorderWidgets: (newOrder: WidgetConfig[]) => void;
}

const defaultWidgets: WidgetConfig[] = [
  { id: 'clock', title: 'Clock', visible: true, order: 0 },
  { id: 'weather', title: 'Weather', visible: true, order: 1 },
  { id: 'quote', title: 'Quote of the Day', visible: true, order: 2 },
  { id: 'todo', title: 'To-Do List', visible: true, order: 3 },
  { id: 'notes', title: 'Notes', visible: true, order: 4 },
];

const SettingsContext = createContext<SettingsContextType | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [widgets, setWidgets] = useState<WidgetConfig[]>(() => {
    const stored = localStorage.getItem('nexus_widgets');
    try { return stored ? JSON.parse(stored) : defaultWidgets; } catch { return defaultWidgets; }
  });

  useEffect(() => {
    localStorage.setItem('nexus_widgets', JSON.stringify(widgets));
  }, [widgets]);

  const toggleWidget = (id: WidgetId) => {
    setWidgets(prev => prev.map(w => w.id === id ? { ...w, visible: !w.visible } : w));
  };

  const reorderWidgets = (newOrder: WidgetConfig[]) => {
    setWidgets(newOrder.map((w, i) => ({ ...w, order: i })));
  };

  return (
    <SettingsContext.Provider value={{ widgets, toggleWidget, reorderWidgets }}>
      {children}
    </SettingsContext.Provider>
  );
}

export const useSettings = () => {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider');
  return ctx;
};
