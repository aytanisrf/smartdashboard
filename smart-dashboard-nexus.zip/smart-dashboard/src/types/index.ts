export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  color: string;
  updatedAt: string;
}

export type WidgetId = 'weather' | 'todo' | 'notes' | 'quote' | 'clock';

export interface WidgetConfig {
  id: WidgetId;
  title: string;
  visible: boolean;
  order: number;
}

export interface DashboardSettings {
  widgets: WidgetConfig[];
  theme: 'light' | 'dark';
}

export interface WeatherData {
  city: string;
  temp: number;
  feelsLike: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

export interface Quote {
  text: string;
  author: string;
}
